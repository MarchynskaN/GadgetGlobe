const gadgets=[
    {
      id:1,
      name:"HP Vivobook 15 15.6\"",
      desc:"Laptop-Slate Grey",
      details:"(Intel Core i3-1111G4/256GB)",
      url:"/laptop.jpg",
      price:240
    
    },
     {
      id:2,
    name:"HP Vivobook 15 15.6\"",
    desc:"Laptop-Slate Grey",
    details:"(Intel Core i3-1111G4/256GB)",
    url:"/laptop.jpg",
    price:240
},
    {
      id:3,
      name:"HP Vivobook 15 15.6\"",
      desc:"Laptop-Slate Grey",
      details:"(Intel Core i3-1111G4/256GB)",
      url:"/laptop.jpg",
      price:240
    },
      {
        id:4,
        name:"HP Vivobook 15 15.6\"",
        desc:"Laptop-Slate Grey",
        details:"(Intel Core i3-1111G4/256GB)",
        url:"/laptop.jpg",
        price:240
    },
        {
          id:5,
          name:"HP Vivobook 15 15.6\"",
          desc:"Laptop-Slate Grey",
          details:"(Intel Core i3-1111G4/256GB)",
          url:"/laptop.jpg",
          price:240
        },
          {
            id:6,
            name:"HP Vivobook 15 15.6\"",
            desc:"Laptop-Slate Grey",
            details:"(Intel Core i3-1111G4/256GB)",
            url:"/laptop.jpg",
            price:"$240"
        },
            {
              id:7,
              name:"HP Vivobook 15 15.6\"",
              desc:"Laptop-Slate Grey",
              details:"(Intel Core i3-1111G4/256GB)",
              url:"/laptop.jpg"
            }
    ];
    export default gadgets;